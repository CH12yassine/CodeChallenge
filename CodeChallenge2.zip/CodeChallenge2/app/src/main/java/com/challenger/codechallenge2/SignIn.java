package com.challenger.codechallenge2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.challenger.codechallenge2.R;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginResult;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import static com.challenger.codechallenge2.MainActivity.loginButton;


public class SignIn extends Fragment {
    EditText gmail;
    EditText psw;
    Button connexion;
    String[] file;
    int lines;
    String mailfromfile;
    String mdpfromfile;
    CallbackManager callbackManager;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.sign_in, parent, false);
        gmail = view.findViewById(R.id.mailin);
        psw = view.findViewById(R.id.pswin);
        connexion = view.findViewById(R.id.connexionin);
        callbackManager= CallbackManager.Factory.create();
       // String email = readFromFile(getActivity(),"email_origin.txt");

        //gmail.setText(email);

        connexion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email2 = gmail.getText().toString();
                String mdp2 = psw.getText().toString();
                String tff = readFromFile(getContext(),"Config.txt");
                file = tff.split("\n");
                try {
                    InputStream inputStream = getContext().openFileInput("Config.txt");
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    while (bufferedReader.readLine() != null) lines++;
                    if(lines!=0) {
                        mailfromfile = file[file.length-1];
                        mdpfromfile = file[file.length - 2];
                    }
                    else {
                    }
                    inputStream.close();
                }
                catch (FileNotFoundException e) {
                    Log.e("login activity", "File not found: " + e.toString());
                } catch (IOException e) {
                    Log.e("login activity", "Can not read file: " + e.toString());
                }

                File path = new File(getActivity().getFilesDir().getAbsoluteFile()+ File.separator + "Config.txt");
                if(path.exists()) {

                   if(email2.equals(mailfromfile) && mdp2.equals(mdpfromfile)) {

                       if(AccessToken.getCurrentAccessToken()==null){
                           connectWithFacebook();
                       }else {
                           startActivity(new Intent(getActivity(), AlbumActivity.class));

                       }

                   }


                     else {
                        Toast.makeText(getActivity(), "mail ou mot de passe incorrecte", Toast.LENGTH_SHORT).show();
                        Fragment currentFragment = getFragmentManager().findFragmentByTag("signIn");
                        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                        fragmentTransaction.detach(currentFragment);
                        fragmentTransaction.attach(currentFragment);
                        fragmentTransaction.commit();
                    }
                }
                else {
                    Toast.makeText(getActivity(), "Veuillez vous enregistrer d'abord", Toast.LENGTH_SHORT).show();
                }


            }
        });
        return view;
    }
    private void connectWithFacebook(){
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                startActivity(new Intent(getContext(),AlbumActivity.class));
            }

            @Override
            public void onCancel() {
                Toast.makeText(getContext(),"Canceled Login",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(FacebookException error) {
                Log.i("FacebookState", "onError: ");
            }
        });
    }
   public static String readFromFile(Context context, String filename) {

       String ret = "";

       try {
           InputStream inputStream = context.openFileInput(filename);

           if ( inputStream != null ) {
               InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
               BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
               String receiveString = "";
               StringBuilder stringBuilder = new StringBuilder();

               while ( (receiveString = bufferedReader.readLine()) != null ) {
                   stringBuilder.append(receiveString);
                   stringBuilder.append("\n");
               }

               inputStream.close();
               ret = stringBuilder.toString();
           }
       }
       catch (FileNotFoundException e) {
           Log.e("login activity", "File not found: " + e.toString());
       } catch (IOException e) {
           Log.e("login activity", "Can not read file: " + e.toString());
       }

       return ret;
   }
    }
