package com.challenger.codechallenge2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class SignUp extends Fragment {
    EditText gmail;
    EditText psw;
    EditText psw2;
    Button connexion;
    protected static String mdpasse;
    String mdp;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        // Defines the xml file for the fragment
        View view = inflater.inflate(R.layout.sign_up, parent, false);
        gmail = view.findViewById(R.id.mail);
        psw = view.findViewById(R.id.psw);
        psw2 = view.findViewById(R.id.psw2);
        connexion = view.findViewById(R.id.connexion);

      //  String email = readFromFile(getActivity(),"email_origin.txt");

       // gmail.setText(email);
        connexion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email2 = gmail.getText().toString();
                mdp = psw.getText().toString();
                String mdp2 = psw2.getText().toString();
                mdpasse = mdp;

                if(!mdp.equals(mdp2)) {
                    Toast.makeText(getActivity(),"mots de passe non identiques",Toast.LENGTH_SHORT).show();
                    Fragment currentFragment = getFragmentManager().findFragmentByTag("signUp");
                    FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                    fragmentTransaction.detach(currentFragment);
                    fragmentTransaction.attach(currentFragment);
                    fragmentTransaction.commit();
                }
                else {
                    File path = new File(getActivity().getFilesDir().getAbsoluteFile()+ File.separator + "Config.txt");
                    boolean deleted = path.delete();
                    File path2 = new File(getActivity().getFilesDir().getAbsoluteFile()+ File.separator + "Config.txt");
                    boolean deleted2 = path2.delete();


                    writeToFile(mdp+"\n","Config.txt");
                    writeToFile(email2+"\n","Config.txt");


                    Intent intent = new Intent(getActivity(),AlbumActivity.class);
                    startActivity(intent);
                }
            }
        });

        return view;
    }

    private void writeToFile(String data, String filename) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(getActivity().openFileOutput(filename, Context.MODE_APPEND));

            outputStreamWriter.write(data);
            outputStreamWriter.close();
        }
        catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
        }
    }
    public static String readFromFile(Context context, String filename) {

        String ret = "";

        try {
            InputStream inputStream = context.openFileInput(filename);

            if ( inputStream != null ) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                StringBuilder stringBuilder = new StringBuilder();

                while ( (receiveString = bufferedReader.readLine()) != null ) {
                    stringBuilder.append(receiveString);
                    stringBuilder.append("\n");
                }

                inputStream.close();
                ret = stringBuilder.toString();
            }
        }
        catch (FileNotFoundException e) {
            Log.e("login activity", "File not found: " + e.toString());
        } catch (IOException e) {
            Log.e("login activity", "Can not read file: " + e.toString());
        }

        return ret;
    }
}
