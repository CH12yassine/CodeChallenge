package com.challenger.codechallenge2;

/**
 * Created by Yassine on 15/11/2018.
 */

public class ImageAlbumModel {
    private String urlImage;

    public ImageAlbumModel(String urlImage){
        this.urlImage=urlImage;
    }

    public String getUrlImage() {
        return urlImage;
    }

    public void setUrlImage(String urlImage) {
        this.urlImage = urlImage;
    }
}
